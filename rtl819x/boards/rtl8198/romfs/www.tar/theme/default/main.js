﻿/* 
	Copyright 2013-2020, 
	All rights reserved.
	Author: Einsn Liu (179712066@qq.com)
	Date: 2013-03-25 
*/

/* Global environment */
var env;
/* Menu List, get from env.js */
var menu;


/* Language define */
var lang_cn = new Array();
lang_cn['System Menu'] = '系统菜单';

lang_cn['System Setting'] = '系统管理';
lang_cn['Management'] = '管理参数';
lang_cn['Switch Setting'] = '设备管理';
lang_cn['Network Topology'] = '业务管理';
lang_cn['User List'] = '用户管理';

lang_cn['System Status'] = '系统状态';
lang_cn['Date & Time'] = '日期及时间';
lang_cn['Configuration'] = '配置管理';
lang_cn['Reboot'] = '系统重启';
lang_cn['Upgrade'] = '软件升级';
lang_cn['System Log'] = '系统日志';

lang_cn['IP Setting'] = '管理IP设置';
lang_cn['Security'] = '管理安全设置';
lang_cn['SNMP'] = 'SNMP设置';
lang_cn['Administrator'] = '管理员';

lang_cn['Interface'] = '端口管理';
lang_cn['StormFilter'] = '广播风暴抑制';
lang_cn['VLAN Mode'] = 'VLAN模式设置';
lang_cn['802.1Q VLAN'] = '802.1Q VLAN';
lang_cn['Trunk VLAN'] = 'Trunk VLAN';
lang_cn['Hybrid VLAN'] = 'Hybrid VLAN';

lang_cn['Master'] = '局端管理';
lang_cn['Topology'] = '网络拓扑';
lang_cn['Template'] = '模板管理';
	
lang_cn['UserList'] = '用户列表';
lang_cn['History'] = '上线记录';
lang_cn['Whitelist'] = '白名单';
lang_cn['Blacklist'] = '黑名单';

lang_cn['VLAN Pool'] = 'VLAN池管理';
lang_cn['Service'] = '服务管理';

lang_cn['Online'] = '在线';
lang_cn['Offline'] = '离线';
lang_cn['Save Changes'] = '保存更新';
lang_cn['Exit'] = '退出';
lang_cn['Are you sure to store all configurations?'] = "确定要保存所有配置吗?";
lang_cn['Total:'] = '总数：';

lang_cn['Device Model'] = '终端设备型号';


function L(str)
{
  if ((env['sys.lang'] == 'cn')
    && (lang_cn[str])){
    return lang_cn[str];  
  }
  return str;   
}

/* end Language define */


/* add left menu item */
function addLeftMenu(name, link, iscurrent)
{
    var style_current = 'menuA menuB';
    var style_static =  'menuA';
    
    var h = '';	
    h += '<li><a class="' + (iscurrent ? style_current : style_static) + '" href="' + link + '"/>' + name + ' </a></li>';
    return h;
}

/* add top menu item */
function addTopMenu(name, link, iscurrent)
{
    var style_current = 'menuC menuD';
    var style_static = 'menuC';
    
    var h = '';	
    h += '<li><a class="' + (iscurrent ? style_current : style_static) + '" href="' + link + '">' + name + '</a></li>';
    return h;
}

/* a script for link 'save' blink and apply */
function saveHtml()
{
    var h = '';
    h += '<script language="javascript"> ';
    
    /* a function for font blinking */	
    h += 'var control = 0;';
    h += 'function fontBlink()';
    h += '{ ';
    h += '	var obj = document.getElementById("blink");';
    h += '	if (obj){';
    h += '		control ++;';
    h += '		obj.style.color = (control & 0x01) ? "black" : "red";';
    h += '	}';
    h += '} ';
    h += 'setInterval("fontBlink()", 300); ';
    h += '</script>';
    return h;
}

function leftMenu(menuPage)
{
    var h = '';
    
    h += '<div id="leftMenu">';
    h += '	<div id="leftMenuTitle"> == ' + L('System Menu') + ' == </div>';
    h += '	<ul>';
    
    for (var i = 0; i < menu.length; i ++){
        var iscurrent = pageInMenu(menu[i].submenu, menuPage);
        h += addLeftMenu(L(menu[i].name), menu[i].page, iscurrent);
    }
    
    h += ' </ul> ';
    h += ' </div>';
    return h;	
}


function topMenu(menuPage)
{
    var h = '';

    h += saveHtml();

    h += '<div id="topBar">';
    h += '<div id="topMenu">';
    h += ' <ul>';

    var topMenu = getSubMenu(menu, menuPage);
    for (var i = 0; i < topMenu.length; i ++){
        var current_page = (menuPage && (menuPage == topMenu[i].page)) ? true : false;
        h += addTopMenu(L(topMenu[i].name), topMenu[i].page, current_page);
    }

    h += ' </ul>';
    h += '</div>';
    h += ' <div id="topStatus">';
    h += '  <a class="online" href="service_map.asp"> ' + L("Online") + ':'+ env['sys.linkup'] +' </a> | ';
    h += '  <a class="offline" href="service_map.asp"> ' + L("Offline") + ': '+ env['sys.linkoff'] +' </a> | ';
    h += '  <a ' + ((env['sys.unsaved'] == '1') ? 'id="blink"' : "") + ' href="javascript:save_apply()"> ' + L("Save Changes") + ' </a>| ';
    h += '  <a href="login.asp"> ' + L("Exit") + ' </a>';
    h += '  </div>';
    h += '  <!--div style="clear:both;height:0px;"> </div-->';
    h += '  </div>';
    
    return h;
}



function rowContent(menuPage)
{
    var h = '';
    h += ' <div id="mainContent">'; //end in front of footer
    h += '	<div id="sidebar">';
    h +=  leftMenu(menuPage);
    h += '  </div>  '; 
    
    h += ' <div id="contentWrap">';  //end in front of footer
    h +=  topMenu(menuPage);

    h += ' <div id="contain">';	//end in front of footer
    return h;
}

function rowHead()
{
    var logo_tag = '&nbsp;';
    if (env['vendor.logo'] != 'none'){
        logo_tag = '<img src="/theme/' + env['sys.theme'] + '/images/logo.png"/>';
    }

    var h = '';
    h +=' <div id="header">';
    h +=' 	<div id="header_logo">' + logo_tag + '</div>';
    h +=' 	<div id="header_title">';
    h +='	<table style="border:0px solid red;width:100%">';
    h +='		<tr><td width=10%> &nbsp;</td>	';
    h +='		<td > &nbsp;</td>';
    h +='		<td width=10%> &nbsp;</td>';
    h +='		</tr>';
    h +='		<tr><td> &nbsp;</td>';
    h +='		<td > <b id=model_name>'+ env['sys.model'] + '&nbsp;' + env['sys.name'] + '</b></td>';
    h +='		<td > &nbsp;</td>';
    h +='		</tr>';
    h +='		<tr><td > &nbsp;</td>';
    h +='		<td >  <b id=sys_version> '+ env['sys.version'] +' </b></td>';
    h +='		<td > &nbsp;</td>';
    h +='		</tr>';
    h +='		</table>';
    h +=' </div> ';
    h +=' </div> ';

    return h;
}

function pageHead(env_in, menuPage)
{
    env = env_in;
    menu = getMenu(env);
    
    var html = '<div id="container"> ';
    html += rowHead();
    html += rowContent(menuPage);
    document.writeln(html);
}

function pageTail()
{
    var html = '';
    html += '</div>'; /* end div conatin */
    html += '</div>'; /* end div contentWrap */
    html += '</div>'; /* end div mainContent */
    html += '<div id="footer"> ';
 //   html += env['sys.name'];
 //   html += " | ";
   // html += ' <a href="' + env['vendor.link'] + '"> ' + "More Products</a>";
    //html += " | ";
    if (env['sys.lang'] == "cn"){
   	  html += '<a href="javascript:set_language(\'en\')">ENGLISH</a>';
    }else {
      html += '<a href="javascript:set_language(\'cn\')">CHINESE</a>';	
    }
    html += " | ";
    html += 'COPYRIGHT © ' + env['vendor.copyright'] + ' <a href="' + env['vendor.link'] + '"> ' + env['vendor.name'] + ' </a> ALL RIGHTS RESERVED.';    

    html += '</div>';
    html += '</div>';
    document.writeln(html);	
}


function save_apply()
{ 
	var f = document.forms[0];
	if( !confirm(L("Are you sure to store all configurations?")))
		return;
	diffCfg("config_0", "config", "save");
	subForm(f,"goform/command", "CONFIG", "index.asp");
}	

function set_language(lang)
{ 
	var f = document.forms[0];	
	diffCfg("config_0", "config", "lang");
	diffCfg("config_1", "value", lang);
	subForm(f,"goform/command", "CONFIG", location);
}	
